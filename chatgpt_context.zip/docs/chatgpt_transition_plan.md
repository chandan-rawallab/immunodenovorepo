# Objective 3: ChatGPT Transition & Handoff Plan

This document outlines the transition plan for taking the **Objective 3 Neoepitope Discovery Pipeline** from this environment to a ChatGPT-assisted interface. 

---

## 1. Packaged Context Zip File

To make the transition seamless, we have created a lightweight, curated context archive:
*   **File Path**: `/home/amity/Documents/experiments/chatgpt_context.zip`
*   **Size**: **188 KB** (extremely small, upload-friendly)
*   **Contents**: Contains 67 key project files across:
    *   `src/`: Complete source code (`cnnlstm`, `data_prep`, `training`, `inference`, `postprocess`, `evaluation`, `validation`).
    *   `configs/`: Registry files, draft manifests, and excluded runs lists.
    *   `docs/`: Design documents, triage logs, and rerun plans.
    *   `manual_run_guide.md`: End-to-end execution workflows.
    *   `tests/`: Test suite files.

---

## 2. Immediate Objective & Remaining Tasks

Once you initialize ChatGPT, your first set of tasks revolves around **Phase 1: Laumont 2018 Cohort Activation**. Here are the next steps you should ask ChatGPT to help you with:

```mermaid
graph TD
    A[Read Supplement for Laumont 2018] --> B[Retrieve HLA Alleles for 6 Human Samples]
    A --> C[Retrieve GEO GSE113972 RNA-seq Mappings]
    B --> D[Update laumont_2018_manifest.draft.tsv]
    C --> D
    D --> E[Change include_in_pipeline = True]
    E --> F[Run Preflight Audit]
```

### Next Actions:
1.  **Retrieve HLA Alleles**: Determine the MHC-I genotypes (HLA-A, -B, -C) for samples `07H103`, `12H018`, `lc2`, `10H080`, `lc4`, and `lc6` from the paper's supplements.
2.  **GEO-to-PRIDE Mapping**: Map the RNA expression datasets from NCBI GEO GSE113972 to the 6 human PRIDE samples.
3.  **Update Manifest**: Open `configs/studies/laumont_2018_manifest.draft.tsv` to input the HLA and RNA paths, and set `include_in_pipeline = True`.
4.  **Clinical Validation List**: Obtain the list of validated neoantigens from the paper to build the evaluation file.

---

## 3. ChatGPT Initializer Prompt

When starting a new session in ChatGPT, upload the `chatgpt_context.zip` file and paste the following prompt:

```text
Hello! I have uploaded a zip file containing the complete codebase, configurations, and documentation for our "Objective 3: Neoepitope Discovery Pipeline" (CNN-LSTM deep learning model for de novo peptide sequencing and immunogenicity ranking).

Please unpack the zip file and review:
1. `manual_run_guide.md` - to understand the step-by-step pipeline execution flow.
2. `docs/laumont_2018_triage.md` - to see the current state of our target cohort (Laumont 2018).
3. `configs/studies/laumont_2018_manifest.draft.tsv` - the manifest file we need to populate.

Our immediate goal is to finalize the Laumont 2018 cohort manifest so we can run the pipeline manually. To do this, I need you to help me:
1. Identify the HLA class I alleles for the 6 ready human samples (07H103, 12H018, lc2, 10H080, lc4, lc6) from the Laumont 2018 publication (Science Translational Medicine, PMID: 30518613).
2. Map the corresponding patient-matched RNA-seq sample accessions from GSE113972 to these PRIDE sample IDs.
3. Formulate the python code edits or tab-separated lines needed to update `configs/studies/laumont_2018_manifest.draft.tsv`.

Let's begin by reviewing the project structure and analyzing the Laumont 2018 paper details!
```

---

## 4. Run commands locally

When ChatGPT gives you code modifications, commands, or data tables, use your local terminal to apply and run them:

### To apply TSV edits:
You can edit files directly using `nano`, `vim`, or VS Code on:
```bash
configs/studies/laumont_2018_manifest.draft.tsv
```

### To run the pipeline steps:
1.  **Validate manifest and file paths**:
    ```bash
    python3 src/validation/preflight_validate.py --manifest configs/studies/laumont_2018_manifest.draft.tsv
    ```
2.  **Clean unlabeled spectra**:
    ```bash
    python3 src/data_prep/05_extract_unlabeled_spectra.py --manifest configs/studies/laumont_2018_manifest.draft.tsv
    ```
3.  **Run prediction, filtering, and ranking**:
    Follow the commands in Section 2 of `manual_run_guide.md`.

---

## 5. Current Blockers & Diagnostics (June 29 Run)

We ran the validation script on the draft manifest:
```bash
python3 src/validation/preflight_validate.py --manifest configs/studies/laumont_2018_manifest.draft.tsv
```

### Preflight Errors:
1.  **Manifest vs Data Files Mismatch**: The current files in `data/psms` and `data/mgf` correspond to the **Bassani cohort** (31 runs), while the manifest contains the **Laumont cohort** (15 runs). This results in a complete mismatch during validation.
2.  **Spectral Extraction Fail**: Running `src/data_prep/05_extract_unlabeled_spectra.py` with the draft manifest results in 0 MGF files processed. This is expected because the 15 Laumont run IDs do not exist locally in `data/mgf/` yet.
3.  **Reference FASTA Fail**: The default reference FASTA (`data/reference/uniprot_human_reviewed.fasta`) contains non-human proteins.
    *   *Solution*: The preflight script should be run with `--reference-fasta data/reference/uniprot_human_reviewed.only_human.fasta` which is a human-only FASTA available in the workspace.
