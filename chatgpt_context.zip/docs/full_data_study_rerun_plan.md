# Objective 3 Full-Data Study Rerun Plan

This plan treats the pasted Objective 3 text as the scientific source of truth: train a CNN-LSTM de novo peptide sequencing model from identified immunopeptidome PSMs, predict unlabeled spectra, filter candidate neoantigens, then rank by HLA binding and patient-matched expression.

## Current Gate

The local Bassani/PXD005231 pipeline is useful for calibration, but it is not a full biological rerun because expression is currently surrogate RNA. The next production-quality study must pass these checks before heavy compute:

- MS/MS raw or MGF files are locally present or reproducibly downloadable.
- PSM/search outputs are present or can be regenerated.
- HLA alleles are explicit and source-labeled.
- RNA/expression is patient-matched, not surrogate or mock.
- Patient/sample IDs link MS, RNA, HLA, variants, and validation tables.
- Validation peptides or neoantigen calls are available for evaluation.

## Execution Order

1. Fix local pipeline blockers and run tests.
2. Complete `configs/studies/study_registry.csv` for each candidate cohort.
3. For the first passing cohort, create `configs/studies/<study_id>_manifest.tsv` using `docs/study_manifest_contract.md`.
4. Run provenance audit before any training or prediction.
5. Generate or normalize PSMs and MGF files into study-specific folders.
6. Train/evaluate CNN-LSTM with peptide-grouped splits.
7. Run de novo prediction on unlabeled spectra.
8. Filter database/self peptides and collapse duplicate sample-peptide rows.
9. Rank with MHCflurry and patient-matched TPM only.
10. Evaluate against the study validation table and compare against Casanovo.

## Recommended Study Order

1. `bassani_pxd005231`: keep as current calibration/training cohort; no biological expression claims until real RNA is found.
2. `laumont_2018`: first full-data triage target because public indexes indicate both immunopeptidomics and RNA accessions.
3. `bassani_2016_native_melanoma`: second triage target because it is highly aligned to neoepitope validation but may require controlled-access RNA/variant resolution.
4. `carreno_2015`: proposal-cited validation target; inventory accessions before compute.

## Source Pointers For Triage

- Bassani/PXD005231 calibration cohort: <https://proteomecentral.proteomexchange.org/cgi/GetDataset?ID=PXD005231>
- Bassani 2016 native melanoma MS cohort: <https://proteomecentral.proteomexchange.org/cgi/GetDataset?ID=PXD004894>
- Laumont 2018 publication record: <https://pubmed.ncbi.nlm.nih.gov/30518613/>
- Laumont 2018 ProteomeXchange example accession: <https://central.proteomexchange.org/PXD009749>
- Laumont 2018 RNA index candidate: `GSE113972`
- Laumont normalized file inventory: `configs/studies/laumont_2018_file_inventory.csv`
- Laumont sample coverage summary: `configs/studies/laumont_2018_sample_inventory_summary.csv`

## Stop Conditions

Do not run heavy training or ranking for a study if:

- `rna_source` cannot be set to a patient-matched label.
- MS run IDs cannot be mapped to patient IDs.
- HLA alleles are missing or inferred without a source.
- Validation data cannot be connected to the same patient identifiers.
- Preflight reports unknown samples, stale outputs, or manifest-output mismatches.
