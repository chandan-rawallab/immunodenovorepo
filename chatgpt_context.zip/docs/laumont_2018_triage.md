# Laumont 2018 Cohort Triage

Objective 3 use case: candidate full-data cohort for de novo sequencing, neoantigen filtering, and patient-matched expression ranking.

## Current Status

Status: `triage_required`

This cohort is a better next target than rerunning Bassani/PXD005231 for biological ranking because PRIDE metadata explicitly says the peptide searches used RNA-seq-built cancer databases. It is not ready for heavy compute yet because exact MS run to RNA sample to HLA to validation mapping still needs to be made explicit.

## Verified Public Metadata

- Publication: Laumont et al., *Science Translational Medicine* 2018, PubMed `30518613`, DOI `10.1126/scitranslmed.aau5516`.
- Core concept: tumor-specific antigen discovery using RNA-seq-derived custom databases and MHC-I immunopeptidomics.
- PRIDE records checked through the PRIDE Archive API:
  - `PXD009749`: `07H103` MHC-I immunopeptidome, human B-ALL sample, complete submission.
  - `PXD009750`: `10H118` MHC-I immunopeptidome, human B-ALL sample, complete submission.
  - `PXD009751`: `12H018` MHC-I immunopeptidome, human B-ALL sample, complete submission.
  - `PXD009752`: `lc2` MHC-I immunopeptidome, human lung adenocarcinoma sample, complete submission.
- PRIDE metadata for these records reports PEAKS 8.5 peptide identification against sample-specific global cancer databases built from RNA-sequencing data.
- `PXD009749` metadata lists sibling PRIDE projects: `PXD009750`, `PXD009751`, `PXD009752`, `PXD009753`, `PXD009754`, `PXD009755`, plus `PXD009064` and `PXD009065`.
- NCBI E-utilities search for `GSE113972` returned GEO records, but the GEO quick text endpoint hung during this pass; sample-level RNA mapping still needs a dedicated inventory step.


## File Inventory Sample

First-page PRIDE file-list checks show the cohort has downloadable analysis inputs and outputs, not only raw files:

- `PXD009749` / `07H103`: `MHC_07H103_Rep1.mgf`, `MHC_07H103_Rep2.mgf`, `MHC_07H103_Rep3.mgf`; corresponding `.raw` files; `peptides_1_1_0.mzid.gz`; `peptides_1_1_0.pride.mztab.gz`; sample-specific FASTA `plc07h103_10__PP140_id_181.fasta`.
- `PXD009752` / `lc2`: `IP_lung_1T_060317_1.mgf`, `IP_lung_1T_060317_2.mgf`; corresponding `.raw` files; `peptides_1_1_0.mzid.gz`; `peptides_1_1_0.pride.mztab.gz`; sample-specific FASTA `lc2_7__lc2PP110_id_165.fasta`.

This means the immediate next task is metadata normalization and sample linkage, not raw format conversion.


## Normalized Inventory Results

Generated files:

- `configs/studies/laumont_2018_file_inventory.csv`: 100 PRIDE file records across 9 linked projects.
- `configs/studies/laumont_2018_sample_inventory_summary.csv`: 11 project/sample coverage rows.

Human samples with metadata-level MGF + identification + search FASTA coverage:

- `PXD009749` / `07H103`: B-ALL, 6 MGF/PRIDE-MGF rows, 3 RAW rows, mzID, mzTab, FASTA.
- `PXD009751` / `12H018`: B-ALL, 6 MGF/PRIDE-MGF rows, 3 RAW rows, mzID, mzTab, FASTA.
- `PXD009752` / `lc2`: lung adenocarcinoma, 4 MGF/PRIDE-MGF rows, 2 RAW rows, mzID, mzTab, FASTA.
- `PXD009753` / `10H080`: B-ALL, 6 MGF/PRIDE-MGF rows, 4 RAW rows, mzID, mzTab, FASTA.
- `PXD009754` / `lc4`: lung adenocarcinoma, 4 MGF/PRIDE-MGF rows, 2 RAW rows, mzID, mzTab, FASTA.
- `PXD009755` / `lc6`: lung adenocarcinoma, 4 MGF/PRIDE-MGF rows, 2 RAW rows, mzID, mzTab, FASTA.

Manual mapping issue found:

- `PXD009750` project metadata/result/FASTA names indicate `10H118`, but MGF peak files are named `MHC_10H018_Rep*.mgf`. Treat `PXD009750` as blocked until the `10H018` vs `10H118` mismatch is resolved from the publication supplement or PRIDE submission context.

Mouse projects are included for completeness but should not drive the human Objective 3 patient neoantigen run:

- `PXD009064` / `EL4`: mouse lymphoma, metadata complete.
- `PXD009065` / `CT26` and `Celine`: mouse colon cancer/CT26-linked records with split result and peak naming.

## Why Not Run Yet

Do not start downloads, training, or ranking until these are resolved:

- Which PRIDE raw files correspond to each biological sample and replicate.
- Whether matching RNA quantification files are directly downloadable and how their sample IDs map to PRIDE sample IDs.
- HLA alleles for each human sample.
- Whether validation peptides/TSAs are available in a table we can connect to the same sample IDs.
- Whether PSM outputs can be extracted from PRIDE files or need local PEAKS/MaxQuant-style regeneration.

## Next Commands To Build Inventory

Use PRIDE file-list APIs first and save only metadata, not raw files:

```bash
curl -L "https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009749/files?pageSize=200"
curl -L "https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009750/files?pageSize=200"
curl -L "https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009751/files?pageSize=200"
curl -L "https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009752/files?pageSize=200"
```

Then build `configs/studies/laumont_2018_manifest.tsv` only after the file inventory proves sample/run/RNA/HLA linkage.

## Source URLs

- <https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009749>
- <https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009750>
- <https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009751>
- <https://www.ebi.ac.uk/pride/ws/archive/v3/projects/PXD009752>
- <https://pubmed.ncbi.nlm.nih.gov/30518613/>
