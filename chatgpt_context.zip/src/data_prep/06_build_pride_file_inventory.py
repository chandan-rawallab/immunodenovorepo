#!/usr/bin/env python3
"""Build a normalized PRIDE file inventory for Objective 3 study triage.

This script fetches PRIDE project and file-list metadata only. It does not
fetch RAW, MGF, mzID, mzTab, FASTA, or any other data payloads.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

PRIDE_PROJECT_URL = "https://www.ebi.ac.uk/pride/ws/archive/v3/projects/{accession}"
PRIDE_FILES_URL = "https://www.ebi.ac.uk/pride/ws/archive/v3/projects/{accession}/files?pageSize={page_size}"

LAUMONT_ACCESSIONS = [
    "PXD009749",
    "PXD009750",
    "PXD009751",
    "PXD009752",
    "PXD009753",
    "PXD009754",
    "PXD009755",
    "PXD009064",
    "PXD009065",
]

FIELDNAMES = [
    "project_accession",
    "project_title",
    "sample_id",
    "replicate",
    "disease",
    "organism",
    "file_name",
    "file_type",
    "file_category_name",
    "file_size_bytes",
    "file_size_mb",
    "checksum",
    "ftp_url",
    "aspera_url",
    "role",
    "is_heavy_raw",
    "is_analysis_input",
    "publication_date",
    "source_api",
]

SUMMARY_FIELDNAMES = [
    "project_accession",
    "sample_id",
    "organism",
    "disease",
    "mgf_files",
    "raw_files",
    "mzid_files",
    "mztab_files",
    "fasta_files",
    "analysis_input_mb",
    "raw_mb",
    "has_mgf",
    "has_identifications",
    "has_search_fasta",
    "metadata_ready_for_manifest",
]


def fetch_json(url: str, timeout: int) -> Any:
    request = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def cv_names(items: list[dict[str, Any]] | None) -> str:
    if not items:
        return ""
    return ";".join(str(item.get("name", "")).strip() for item in items if item.get("name"))


def canonical_sample_id(value: str) -> str:
    value = value.strip()
    if not value:
        return ""
    if re.fullmatch(r"lc\d+", value, flags=re.IGNORECASE):
        return value.lower()
    if value.lower() == "celine":
        return "Celine"
    return value.upper()


def project_sample_id(project: dict[str, Any]) -> str:
    title = str(project.get("title", ""))
    patterns = [
        r"\b(?:the\s+)?([A-Za-z0-9]+)\s+MHC class I\b",
        r"\b(?:the\s+)?([A-Za-z0-9]+)\s+MHC I\b",
        r"\b(MHC|IP)[_-]([A-Za-z0-9]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, title, flags=re.IGNORECASE)
        if match:
            return canonical_sample_id(match.group(match.lastindex or 1))
    return ""


def infer_sample_id(file_name: str, fallback: str) -> str:
    patterns = [
        r"MHC_([A-Za-z0-9]+)_Rep\d+",
        r"MHC_([A-Za-z0-9]+)",
        r"plc([A-Za-z0-9]+)_",
        r"\b(lc\d+)\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, file_name, flags=re.IGNORECASE)
        if match:
            return canonical_sample_id(match.group(1))
    return canonical_sample_id(fallback)


def infer_replicate(file_name: str) -> str:
    patterns = [r"Rep(\d+)", r"_(\d+)\.(?:raw|mgf|mzid|gz)$", r"_(\d+)\.pride\.mgf\.gz$"]
    for pattern in patterns:
        match = re.search(pattern, file_name, flags=re.IGNORECASE)
        if match:
            return match.group(1)
    return ""


def file_locations(file_record: dict[str, Any]) -> tuple[str, str]:
    ftp_url = ""
    aspera_url = ""
    for loc in file_record.get("publicFileLocations", []) or []:
        name = str(loc.get("name", "")).lower()
        value = str(loc.get("value", ""))
        if "ftp" in name or value.startswith("ftp://"):
            ftp_url = value
        elif "aspera" in name or value.startswith("prd_ascp@"):
            aspera_url = value
    return ftp_url, aspera_url


def normalize_file_type(file_record: dict[str, Any]) -> str:
    category = file_record.get("fileCategory", {}) or {}
    value = str(category.get("value", "")).upper()
    file_name = str(file_record.get("fileName", "")).lower()
    if value:
        return value
    if file_name.endswith(".raw"):
        return "RAW"
    if ".mgf" in file_name:
        return "PEAK"
    if ".mzid" in file_name or ".mztab" in file_name:
        return "RESULT"
    if file_name.endswith(".fasta") or ".fasta" in file_name:
        return "FASTA"
    return "OTHER"


def infer_role(file_type: str, file_name: str) -> str:
    lower = file_name.lower()
    if file_type == "RAW":
        return "raw_spectrum"
    if ".mgf" in lower:
        return "peak_list_mgf"
    if ".mzid" in lower:
        return "identification_mzid"
    if ".mztab" in lower:
        return "identification_mztab"
    if ".fasta" in lower:
        return "rna_seq_derived_search_fasta"
    return "other_metadata_or_result"


def normalize_record(project: dict[str, Any], file_record: dict[str, Any], timeout: int) -> dict[str, str]:
    project_accession = str(project.get("accession", ""))
    project_title = str(project.get("title", ""))
    file_name = str(file_record.get("fileName", ""))
    file_type = normalize_file_type(file_record)
    role = infer_role(file_type, file_name)
    size_bytes = int(file_record.get("fileSizeBytes") or 0)
    ftp_url, aspera_url = file_locations(file_record)
    category = file_record.get("fileCategory", {}) or {}
    sample_fallback = project_sample_id(project)

    return {
        "project_accession": project_accession,
        "project_title": project_title,
        "sample_id": infer_sample_id(file_name, sample_fallback),
        "replicate": infer_replicate(file_name),
        "disease": cv_names(project.get("diseases")),
        "organism": cv_names(project.get("organisms")),
        "file_name": file_name,
        "file_type": file_type,
        "file_category_name": str(category.get("name", "")),
        "file_size_bytes": str(size_bytes),
        "file_size_mb": f"{size_bytes / 1_000_000:.2f}" if size_bytes else "0.00",
        "checksum": str(file_record.get("checksum", "")),
        "ftp_url": ftp_url,
        "aspera_url": aspera_url,
        "role": role,
        "is_heavy_raw": str(file_type == "RAW" and size_bytes > 100_000_000),
        "is_analysis_input": str(role in {"peak_list_mgf", "identification_mzid", "identification_mztab", "rna_seq_derived_search_fasta"}),
        "publication_date": str(file_record.get("publicationDate") or project.get("publicationDate") or ""),
        "source_api": PRIDE_FILES_URL.format(accession=project_accession, page_size="<page_size>"),
    }


def build_inventory(accessions: list[str], timeout: int, page_size: int) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for accession in accessions:
        project_url = PRIDE_PROJECT_URL.format(accession=accession)
        files_url = PRIDE_FILES_URL.format(accession=accession, page_size=page_size)
        try:
            project = fetch_json(project_url, timeout)
            files = fetch_json(files_url, timeout)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            print(f"WARN: failed to fetch {accession}: {exc}", file=sys.stderr)
            continue
        if isinstance(files, dict) and "list" in files:
            files = files["list"]
        if not isinstance(files, list):
            print(f"WARN: unexpected file-list payload for {accession}", file=sys.stderr)
            continue
        for file_record in files:
            rows.append(normalize_record(project, file_record, timeout))
    rows.sort(key=lambda r: (r["project_accession"], r["sample_id"], r["role"], r["replicate"], r["file_name"]))
    return rows


def write_csv(rows: list[dict[str, str]], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def build_summary(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    grouped: dict[tuple[str, str], list[dict[str, str]]] = {}
    for row in rows:
        grouped.setdefault((row["project_accession"], row["sample_id"]), []).append(row)

    summary_rows: list[dict[str, str]] = []
    for (project_accession, sample_id), group in grouped.items():
        roles = [row["role"] for row in group]
        analysis_mb = sum(float(row["file_size_mb"] or 0) for row in group if row["is_analysis_input"] == "True")
        raw_mb = sum(float(row["file_size_mb"] or 0) for row in group if row["role"] == "raw_spectrum")
        has_mgf = "peak_list_mgf" in roles
        has_identifications = "identification_mzid" in roles or "identification_mztab" in roles
        has_search_fasta = "rna_seq_derived_search_fasta" in roles
        summary_rows.append({
            "project_accession": project_accession,
            "sample_id": sample_id,
            "organism": group[0]["organism"],
            "disease": group[0]["disease"],
            "mgf_files": str(sum(1 for role in roles if role == "peak_list_mgf")),
            "raw_files": str(sum(1 for role in roles if role == "raw_spectrum")),
            "mzid_files": str(sum(1 for role in roles if role == "identification_mzid")),
            "mztab_files": str(sum(1 for role in roles if role == "identification_mztab")),
            "fasta_files": str(sum(1 for role in roles if role == "rna_seq_derived_search_fasta")),
            "analysis_input_mb": f"{analysis_mb:.2f}",
            "raw_mb": f"{raw_mb:.2f}",
            "has_mgf": str(has_mgf),
            "has_identifications": str(has_identifications),
            "has_search_fasta": str(has_search_fasta),
            "metadata_ready_for_manifest": str(bool(sample_id) and has_mgf and has_identifications and has_search_fasta),
        })
    summary_rows.sort(key=lambda r: (r["project_accession"], r["sample_id"]))
    return summary_rows


def write_summary_csv(rows: list[dict[str, str]], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build normalized PRIDE file inventory metadata.")
    parser.add_argument(
        "--accession",
        action="append",
        dest="accessions",
        help="PRIDE accession to inventory. Can be passed multiple times. Defaults to Laumont 2018 accessions.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("configs/studies/laumont_2018_file_inventory.csv"),
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=Path("configs/studies/laumont_2018_sample_inventory_summary.csv"),
    )
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--page-size", type=int, default=500)
    args = parser.parse_args()

    rows = build_inventory(args.accessions or LAUMONT_ACCESSIONS, args.timeout, args.page_size)
    write_csv(rows, args.output)
    summary_rows = build_summary(rows)
    write_summary_csv(summary_rows, args.summary_output)
    print(f"Wrote {len(rows)} file records to {args.output}")
    print(f"Wrote {len(summary_rows)} sample summary rows to {args.summary_output}")
    return 0 if rows else 1


if __name__ == "__main__":
    raise SystemExit(main())
